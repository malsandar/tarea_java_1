/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasemillas;

/**
 *
 * @author Julio
 */
public class Semilla {
    private int llaveSemilla;
    private String nombreSemilla;
    private String descubridorSemilla;
    private int anioSemilla;
    private String regionSemilla;
    private String origenSemilla;

    public Semilla(int llaveSemilla, String nombreSemilla, String descubridorSemilla, int anioSemilla, String regionSemilla, String origenSemilla) {
        this.llaveSemilla = llaveSemilla;
        this.nombreSemilla = nombreSemilla;
        this.descubridorSemilla = descubridorSemilla;
        this.anioSemilla = anioSemilla;
        this.regionSemilla = regionSemilla;
        this.origenSemilla = origenSemilla;
    }

    public int getLlaveSemilla() {
        return llaveSemilla;
    }

    public void setLlaveSemilla(int llaveSemilla) {
        this.llaveSemilla = llaveSemilla;
    }

    public String getNombreSemilla() {
        return nombreSemilla;
    }

    public void setNombreSemilla(String nombreSemilla) {
        this.nombreSemilla = nombreSemilla;
    }

    public String getDescubridorSemilla() {
        return descubridorSemilla;
    }

    public void setDescubridorSemilla(String descubridorSemilla) {
        this.descubridorSemilla = descubridorSemilla;
    }

    public int getAnioSemilla() {
        return anioSemilla;
    }

    public void setAnioSemilla(int anioSemilla) {
        this.anioSemilla = anioSemilla;
    }

    public String getRegionSemilla() {
        return regionSemilla;
    }

    public void setRegionSemilla(String regionSemilla) {
        this.regionSemilla = regionSemilla;
    }

    public String getOrigenSemilla() {
        return origenSemilla;
    }

    public void setOrigenSemilla(String origenSemilla) {
        this.origenSemilla = origenSemilla;
    }
    
    public void printSemilla(){
            System.out.println("ID semilla: "+this.llaveSemilla);
            System.out.println("Nombre de la semilla: "+this.nombreSemilla);
            System.out.println("Descubridor de la semilla: "+this.descubridorSemilla);
            System.out.println("Anio de la semilla: "+this.anioSemilla);
            System.out.println("Region de la semilla: "+this.regionSemilla);
            System.out.println("Obtencion de la semilla: "+this.origenSemilla);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasemillas;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 *
 * @author Julio
 */
public class Menu {
    private int contador;
    
    public Menu(){
        this.contador = 1;
    }

    public Menu(int contador) {
        this.contador = contador;
    }

    public int getContador() {
        return contador;
    }

    public void setContador(int contador) {
        this.contador = contador;
    }
    
    public void menu(Semillero semillero, int cont) throws IOException{
        if(cont != 0){
            this.setContador(cont);
        }
        System.out.println("Semillero Vinia del Mar\n--------------------\n");
        int opcion;
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        do{
            System.out.println("\n\n--------------\nIngrese la opcion segun lo que desea realizar:\n1.- Agregar Nueva Familia\n2.- Agregar Nueva Semilla");
            System.out.println("3.- Listar Familias\n4.- Listar Semillas de una Familia\n5.- Listar Todas las Semillas\n6.- Salir\nOpcion: ");
            opcion = Integer.parseInt(br.readLine());
            switch(opcion){
                case 1:
                    System.out.println("Ingrese el nombre de la nueva familia: ");
                    semillero.crearFamiliaSemilla(br.readLine());
                    break;
                case 2:
                    do{
                        System.out.println("Seleccione el número de la familia que desea agregar:");
                        cont = semillero.printSemillero(true);
                        System.out.println("Opcion: ");
                        opcion = Integer.parseInt(br.readLine());
                        }while(opcion < 1 || opcion > cont);
                    String nombreSemilla, descubridorSemilla, regionSemilla, origenSemilla;
                    int anioSemilla;
                    System.out.print("Nombre: ");
                    nombreSemilla = br.readLine();
                    System.out.print("Descubridor: ");
                    descubridorSemilla = br.readLine();
                    System.out.print("Anio Semilla: ");
                    anioSemilla = Integer.parseInt(br.readLine());
                    System.out.print("Region de la semilla: ");
                    regionSemilla = br.readLine();
                    System.out.print("Origen de la semilla: ");
                    origenSemilla = br.readLine();
                    if(semillero.crearSemilla(this.contador, nombreSemilla, semillero.getFamilia(opcion-1).getNombreFamilia(), descubridorSemilla, anioSemilla, regionSemilla, origenSemilla))
                        this.contador++;
                    break;
                    
                case 3:
                    System.out.println("\nListado de familias de semilla\n-----------------");
                    semillero.printSemillero();
                    break;
                    
                case 4: 
                    do{
                        System.out.println("Seleccione el número de la familia que desea listar:");
                        cont = semillero.printSemillero(true);
                        if(cont == 0){
                            System.out.println("No existen familias registradas");
                            break;
                        }
                        System.out.println("Opcion: ");
                        opcion = Integer.parseInt(br.readLine());
                        }while(opcion < 1 || opcion > cont);
                    if(cont != 0)
                        semillero.printSemilleroEspecifico(opcion-1);
                    opcion = 4;
                    break;
                    
                case 5:
                    System.out.println("\nListado de todas las semillas por familia\n-----------------");
                    semillero.printSemilleroConSemillas();
                    break;
                case 6:
                    System.out.println("Gracias por usar el sistema.");
                    break;
                    
                default:
                    System.out.println("Opcion no valida.");
               
            }
            if(opcion != 6)
                opcion = 99;
        }while(opcion < 0 || opcion > 6);
        
    }
}

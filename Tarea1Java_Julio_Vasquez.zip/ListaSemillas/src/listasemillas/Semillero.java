/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasemillas;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Julio
 */
public class Semillero {

    private List<FamiliaSemilla> semillero;

    public Semillero() {
        this.semillero = new ArrayList<FamiliaSemilla>();
    }

    public boolean crearFamiliaSemilla(String nombre) {
        boolean flag = true;
        for (FamiliaSemilla lista : this.semillero) {
            if (lista.getNombreFamilia().equals(nombre)) {
                flag = false;
                System.out.println("El nombre de la familia ya se encuentra listado.");
                break;
            }
        }
        if (flag) {
            FamiliaSemilla e = new FamiliaSemilla(nombre);
            this.semillero.add(e);
            return true;
        }
        return false;
    }

    //(int llaveSemilla, String nombreSemilla, String descubridorSemilla, int anioSemilla, String regionSemilla, String origenSemilla)
    public boolean crearSemilla(int semillaLLave, String nombreSemilla, String nombreFamilia, String descubridorSemilla, int anioSemilla, String regionSemilla, String origenSemilla) {
        for (FamiliaSemilla elemento : this.semillero) {
            if (elemento.getNombreFamilia().equals(nombreFamilia)) {
                if (!elemento.crearSemilla(semillaLLave, nombreSemilla, descubridorSemilla, anioSemilla, regionSemilla, origenSemilla)) {
                    System.out.println("La semilla no pudo ser agregada.");
                    return false;
                }
                return true;
            }
        }
        System.out.println("La semilla no pudo ser agregada, ya que no se encontró la familia.");
        return false;
    }

    public void printSemillero() {
        if (this.semillero.isEmpty()) {
            System.out.println("No existen familias registradas");
        } else {
            for (FamiliaSemilla lista : this.semillero) {
                lista.printFamilia();
            }
        }
    }

    public void printSemilleroConSemillas() {
        if (this.semillero.isEmpty()) {
            System.out.println("No existen familias registradas");
        } else {
            for (FamiliaSemilla lista : this.semillero) {
                lista.printFamiliaConSemillas();
            }
        }
    }

    public int printSemillero(boolean conNumeros) {
        int contador = 1;
        for (FamiliaSemilla lista : this.semillero) {
            System.out.print(contador + ".- ");
            lista.printFamilia();
            contador++;
        }
        return contador - 1;
    }

    public void printSemilleroEspecifico(int posicion) {
        this.semillero.get(posicion).printSemillas();
    }

    public FamiliaSemilla getFamilia(int posicion) {
        return this.semillero.get(posicion);
    }
}

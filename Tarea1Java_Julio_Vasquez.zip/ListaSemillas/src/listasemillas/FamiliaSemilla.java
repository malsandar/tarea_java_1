/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasemillas;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Julio
 */
public class FamiliaSemilla {
    private String nombreFamilia;
    private List<Semilla> semillas;
    
    public FamiliaSemilla(String nombreFamilia) {
        this.nombreFamilia = nombreFamilia;
        this.semillas = new ArrayList<Semilla>();
    }

    public String getNombreFamilia() {
        return nombreFamilia;
    }

    public void setNombreFamilia(String nombreFamilia) {
        this.nombreFamilia = nombreFamilia;
    }

    public List<Semilla> getSemillas() {
        return semillas;
    }

    public void setSemillas(List<Semilla> semillas) {
        this.semillas = semillas;
    }
    
    public boolean crearSemilla(int semillaLLave,String nombreSemilla ,String descubridorSemilla, int anioSemilla, String regionSemilla, String origenSemilla){
        boolean flag = true;
        for(Semilla elemento: this.semillas){
            if(elemento.getLlaveSemilla() == semillaLLave){
                flag = false;
                System.out.println("No se puede crear semilla, porque ya se encuentra registrada. (1)");
            }
            if(elemento.getNombreSemilla().equals(nombreSemilla) && elemento.getAnioSemilla()==anioSemilla && elemento.getRegionSemilla().equals(regionSemilla) && elemento.getOrigenSemilla().equals(origenSemilla)){
                //if()
                flag = false;
                System.out.println("No se puede crear semilla, porque ya se encuentra registrada. (2)");
            }
        }
        if(flag){
            Semilla semilla = new Semilla(semillaLLave, nombreSemilla , descubridorSemilla,  anioSemilla,  regionSemilla,  origenSemilla);
            this.semillas.add(semilla);
            return true;
        }
        return false;
    }
    
    public void printFamilia(){
        System.out.println("Familia: "+this.nombreFamilia);
    }
    
    public void printFamiliaConSemillas(){
        System.out.println("\n\nFamilia: "+this.nombreFamilia+"\n--------------");
        this.printSemillas();
    }
    
    public void printSemillas(){
        for(Semilla semilla: this.semillas){
            semilla.printSemilla();
        }
    }
    
}
